<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>SPP | Edit Data Histori Pembayaran</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="../assets/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/modules/fontawesome/css/all.min.css">

  <!-- CSS Libraries -->
  <link rel="stylesheet" href="../assets/modules/jquery-selectric/selectric.css">

  <!-- Template CSS -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/components.css">
<!-- Start GA -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-94034622-3');
</script>
<!-- /END GA --></head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
            

            <div class="card card-primary">
              <div class="card-header"><h4>Edit Data Histori Pembayaran</h4></div>
              <?php 
                    include "../koneksi.php";
                    $id = $_GET['id_pembayaran'];
                    $query_mysql = mysqli_query($koneksi,"SELECT * FROM pembayaran WHERE id_pembayaran='$id' ")or die(mysql_error());
                    $nomor = 1;
                    while($data = mysqli_fetch_array($query_mysql)) {
            ?>
              <div class="card-body">
                <form method="POST" action="AE_Histori-Pembayaran.php">
                <div class="form-group">
                    <label for="ID_PEMBAYARAN">ID PEMBAYARAN</label>
                    <input id="ID_PEMBAYARAN" type="text" class="form-control" name="id_pembayaran" value="<?php echo $data['id_pembayaran'] ?>" readonly>
                    <div class="invalid-feedback">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="ID_PETUGAS">ID PETUGAS</label>
                    <input id="ID_PETUGAS" type="text" class="form-control" name="id_petugas" value="<?php echo $data['id_petugas'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="NISN">NISN</label>
                    <input id="NISN" type="text" class="form-control" name="nisn" value="<?php echo $data['nisn'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                    <div class="form-group">
                    <label for="TGL_BAYAR">TANGGAL BAYAR</label>
                    <input id="TGL_BAYAR" type="text" class="form-control" name="tgl_bayar" value="<?php echo $data['tgl_bayar'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                </div>
                
                <div class="form-group">
                      <label>BULAN DIBAYAR</label>
                      <select class="form-control selectric" name="bulan_dibayar" required>
                      <option value="">~~ BULAN DIBAYAR ~~</option>
                        <option value="JANUARI">JANUARI</option>
                        <option value="FEBRUARI">FEBRUARI</option>
                        <option value="MARET">MARET</option>
                        <option value="APRIL">APRIL</option>
                        <option value="MEI">MEI</option>
                        <option value="JUNI">JUNI</option>
                        <option value="JULI">JULI</option>
                        <option value="AGUSTUS">AGUSTUS</option>
                        <option value="SEPTEMBER">SEPTEMBER</option>
                        <option value="OKTOBER">OKTOBER</option>
                        <option value="NOVEMBER">NOVEMBER</option>
                        <option value="DESEMBER">DESEMBER</option>
                      </select>
                    </div>
               
                  
                    <div class="form-group">
                    <label for="TAHUN_DIBAYAR">TAHUN DIBAYAR</label>
                    <input id="TAHUN_DIBAYAR" type="text" class="form-control" name="tahun_dibayar" value="<?php echo $data['tahun_dibayar'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="ID_SPP">ID SPP</label>
                    <input id="ID_SPP" type="text" class="form-control" name="id_spp" value="<?php echo $data['id_spp'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="JUMLAH_BAYAR">JUMLAH BAYAR</label>
                    <input id="JUMLAH_BAYAR" type="text" class="form-control" name="jumlah_bayar" value="<?php echo $data['jumlah_bayar'] ?>" required>
                    <div class="invalid-feedback">
                    </div>
                  </div>

                      
                  
                  
                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">
                      EDIT DATA HISTORI PEMBAYARAN
                    </button>
                    
                  </div>
                </form>
                <?php } ?>
                <a href="Histori-Pembayaran.php" class="btn btn-secondary btn-lg btn-block">
                      KEMBALI
                </a>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include "../Template-SPP/Footer.php"; ?>
  <!-- General JS Scripts -->
  <script src="assets/modules/jquery.min.js"></script>
  <script src="assets/modules/popper.js"></script>
  <script src="assets/modules/tooltip.js"></script>
  <script src="assets/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="assets/modules/moment.min.js"></script>
  <script src="assets/js/stisla.js"></script>
  
  <!-- JS Libraies -->
  <script src="assets/modules/jquery-pwstrength/jquery.pwstrength.min.js"></script>
  <script src="assets/modules/jquery-selectric/jquery.selectric.min.js"></script>

  <!-- Page Specific JS File -->
  <script src="assets/js/page/auth-register.js"></script>
  
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  <script src="assets/js/custom.js"></script>
</body>
</html>