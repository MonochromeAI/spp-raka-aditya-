<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>
 <!-- Main Content -->
 <div class="main-content">
          <section class="section">
            <div class="row">
              <div class="col">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title text-center"></<h1><b>DATA KELAS</b></h1>
                    </div>
                    <div class="card-stats-items">
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">42</div>
                        <div class="card-stats-item-label">Jumlah Seluruh Kelas</div>
                      </div>
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">9</div>
                        <div class="card-stats-item-label">Jumlah Kelas RPL</div>
                      </div>
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">6</div>
                        <div class="card-stats-item-label">Jumlah Kelas DPIB</div>
                      </div>
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">9</div>
                        <div class="card-stats-item-label">Jumlah Kelas TAV</div>
                      </div>
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">9</div>
                        <div class="card-stats-item-label">Jumlah Kelas TKRO</div>
                      </div>
                      <div class="card-stats-item">
                        <div class="card-stats-item-count">9</div>
                        <div class="card-stats-item-label">Jumlah Kelas TBSM</div>
                      </div>
                    </div>
                  </div>
                 
                  <div class="card-wrap">
                    <div class="card-header">
            <div class="row">
            <?php
            if(isset($GET['pesan'])){
              $pesan=$_GET['pesan'];
            if ($pesan == "input"){
              echo "Data Berhasil Diinput.";
            }else if ($pesan =="update"){
              echo "Data Berhasil Diupdate.";
            }else if ($pesan == "hapus"){
                echo "Data Berhasil Dihapus."; 
              }
              }
          ?>

          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="text-center">DATA KELAS</h4>
                  <a href="T_kelas.php" class="btn btn-primary">Tambah Data Kelas</a>
                </div>
              </div>
            </div>
          </div>
        
                        <div class="table-responsive table-invoice">
            
                    <table class="table table-striped">
                      <tr class="text-center">
                        <th>ID Kelas</th>
                        <th>Nama Kelas</th>
                        <th>Kompetensi Keahlian</th>
                        <th>Action</th>
                      </tr>
            
                      <?php
                      include "../koneksi.php";
                      $query_mysql = mysqli_query($koneksi,"select * from kelas");
                      $nomor = 1;
while($data = mysqli_fetch_array($query_mysql)){
  ?>
  <tr class="text-center">
    <td><?php echo $data['id_kelas']; ?></td>
    <td>
      <div class="badge badge-info"><?php echo $data['nama_kelas']; ?></div>
</td>
<td><?php echo $data['kompetensi_keahlian']; ?></td>
<td>
  <a href="E_Kelas.php?id_kelas=<?php echo $data['id_kelas']; ?>" class="btn btn-primary">Edit</a>
  <a href="H_Kelas.php?id_kelas=<?php echo $data['id_kelas']; ?>" class="btn btn-primary">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
</div>
</div>
</div>
</section>
</div>
<?php
include "../Template-SPP/Footer.php";
?>






          
  
    <!-- General JS Scripts -->
    <script src="../assets/modules/jquery.min.js"></script>
    <script src="../assets/modules/popper.js"></script>
    <script src="../assets/modules/tooltip.js"></script>
    <script src="../assets/modules/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
    <script src="../assets/modules/moment.min.js"></script>
    <script src="../assets/js/stisla.js"></script>

    <!-- JS Libraies -->
    <script src="../assets/modules/jquery.sparkline.min.js"></script>
    <script src="../assets/modules/chart.min.js"></script>
    <script src="../assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
    <script src="../assets/modules/summernote/summernote-bs4.js"></script>
    <script src="../assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

    <!-- Page Specific JS File -->
    <script src="assets/js/page/index.js"></script>

    <!-- Template JS File -->
    <script src="../assets/js/scripts.js"></script>
    <script src="../assets/js/custom.js"></script>
  </body>
</html>
