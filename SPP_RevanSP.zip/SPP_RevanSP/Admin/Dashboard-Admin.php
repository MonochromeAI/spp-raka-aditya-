<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>
 <!-- Main Content -->
 <div class="main-content">
          <section class="section">
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-icon shadow-warning bg-warning">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                    <h4>Total Siswa</h4>
                    </div>
                    <div class="card-body">69</div>
                  </div>
                </div>
              </div>

          
              <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="card card-statistic-2">
                  <div class="card-chart">
                    
                  </div>
                  <div class="card-icon shadow-warning bg-warning">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Kelas</h4>
                    </div>
                    <div class="card-body">42</div>
                  </div>
                </div>
              </div>

              <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-chart">
                  </div>
                  <div class="card-icon shadow-warning bg-warning">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Data SPP</h4>
                    </div>
                    <div class="card-body">24434</div>
                  </div>
                </div>
              </div>
            </div>

            <div class="float-left col-lg-6 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-icon shadow-success bg-success">
                    <i class="fas fa-credit-card"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                    <h4>Total Transaksi Bulanan</h4>
                    </div>
                    <div class="card-body">Rp. 500.000</div>
                  </div>
                </div>
              </div>

              <div class="float-right col-lg-6 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-icon shadow-success bg-success">
                    <i class="fas fa-credit-card"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                    <h4>Total Transaksi Tahunan</h4>
                    </div>
                    <div class="card-body">Rp. 1000.000.000</div>
                  </div>
                </div>
              </div>

                
                
            <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h4>Data Transaksi Pembayaran SPP</h4>
                  <div class="card-header-action">
                    
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped table-light">
                      <tr class="text-center">
                        <th>ID</th>
                        <th>NISN</th>
                        <th>Nama Siswa</th>
                        <th>Tanggal Bayar</th>
                        <th>Jumlah Bayar</th>
                        <th>Petugas</th>
                      </tr>
                      <tr class="text-center">
                        <td><a href="#">TDR-3000</a></td>
                        <td>1011.101.69</td>
                        <td>Leiivan</td>
                        <td>March 15, 2069</td>
                        <td>Rp. 1000</td>
                        <td> <div class="badge badge-primary">Miku MMJ</td>
                      </tr>
                      <tr class="text-center">
                        <td><a href="#">PCJ-600</a></td>
                        <td>1011.101.39</td>
                        <td>Hatsune Miku</td>
                        <td>August 28, 2039</td>
                        <td>Rp. 39.000</td>
                        <td> <div class="badge badge-success">Miku VBS</td>
                      </tr>
                     
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
           
    <?php include "../Template-SPP/Footer.php"; ?>
    <!-- General JS Scripts -->
    <script src="../assets/modules/jquery.min.js"></script>
    <script src="../assets/modules/popper.js"></script>
    <script src="../assets/modules/tooltip.js"></script>
    <script src="../assets/modules/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
    <script src="../assets/modules/moment.min.js"></script>
    <script src="../assets/js/stisla.js"></script>

    <!-- JS Libraies -->
    <script src="../assets/modules/jquery.sparkline.min.js"></script>
    <script src="../assets/modules/chart.min.js"></script>
    <script src="../assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
    <script src="../assets/modules/summernote/summernote-bs4.js"></script>
    <script src="../assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

    <!-- Page Specific JS File -->
    <script src="assets/js/page/index.js"></script>

    <!-- Template JS File -->
    <script src="../assets/js/scripts.js"></script>
    <script src="../assets/js/custom.js"></script>
  </body>
</html>
