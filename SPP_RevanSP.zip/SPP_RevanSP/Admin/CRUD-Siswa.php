<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="row">
            <div class="col">
                <div class="card card-statistic-2">
                    <div class="card-stats">
                        <div class="card-stats-title text-center"><h1> Data Siswa</h1>
                            
                        </div>

                    </div>
                    
                </div>
            </div>
        </div>
        <div class="row">
            
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Siswa</h4>
                        <div class="card-header-action">
                            <a href="../Admin/T_Siswa.php" class="btn btn-primary">Tambah Data Siswa</a>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive table-invoice">
                            <table class="table table-striped">
                                <tr class="text-center">
                                    <th>NISN</th>
                                    <th>NIS</th>
                                    <th>NAMA</th>
                                    <th>ID KELAS</th>
                                    <th>ALAMAT</th>
                                    <th>NO. TELP</th>
                                    <th>ID SPP</th>
                                    <th>ACTION</th>
                                </tr>
                                <?php
                      include "../koneksi.php";
                      $query_mysql = mysqli_query($koneksi,"select * from siswa");
                      $nomor = 1;
while($data = mysqli_fetch_array($query_mysql)){
  ?>
  <tr class="text-center">
    <td class="font-weight-600"><?php echo $data['nisn']; ?></td>
    <td>
      <div class="font-weight-600"><?php echo $data['nis']; ?></div>
</td>
<td>
      <div class="font-weight-600"><?php echo $data['nama']; ?></div>
</td>
<td class="font-weight-600"><?php echo $data['id_kelas']; ?>
</td>
<td class="font-weight-600"><?php echo $data['alamat']; ?>
</td>
<td class="font-weight-600"><?php echo $data['no_telp']; ?>
</td>
<td class="font-weight-600"><?php echo $data['id_spp']; ?>
</td>

<td>
  <a href="E_Siswa.php?nisn=<?php echo $data['nisn']; ?>" class="btn btn-primary">Edit</a>
  <a href="H_Siswa.php?nisn=<?php echo $data['nisn']; ?>" class="btn btn-primary">Hapus</a>
</td>
</tr>
<?php } ?>
                                    
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php include "../Template-SPP/Footer.php"; ?>
<!-- General JS Scripts -->
<script src="../assets/modules/jquery.min.js"></script>
    <script src="../assets/modules/popper.js"></script>
    <script src="../assets/modules/tooltip.js"></script>
    <script src="../assets/modules/bootstrap/js/bootstrap.min.js"></script>
    <script src="../assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
    <script src="../assets/modules/moment.min.js"></script>
    <script src="../assets/js/stisla.js"></script>

    <!-- JS Libraies -->
    <script src="../assets/modules/jquery.sparkline.min.js"></script>
    <script src="../assets/modules/chart.min.js"></script>
    <script src="../assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
    <script src="../assets/modules/summernote/summernote-bs4.js"></script>
    <script src="../assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

    <!-- Page Specific JS File -->
    <script src="assets/js/page/index.js"></script>

    <!-- Template JS File -->
    <script src="../assets/js/scripts.js"></script>
    <script src="../assets/js/custom.js"></script>
  </body>
</html>